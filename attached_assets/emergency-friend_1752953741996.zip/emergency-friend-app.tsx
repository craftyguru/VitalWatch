"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import { Button } from "@/components/ui/button"
import { EmergencyButton } from "./components/emergency-button"
import { ContactManager } from "./components/contact-manager"
import { CheckInTimerComponent } from "./components/check-in-timer"
import { EmergencyMode } from "./components/emergency-mode"
import { Dashboard } from "./components/dashboard"
import { EvidenceVault } from "./components/evidence-vault"
import { Settings } from "./components/settings"
import { IncognitoMode } from "./components/incognito-mode"
import { DisguiseMode } from "./components/disguise-mode"
import { Home, Users, Clock, Shield, ArrowLeft, SettingsIcon } from "lucide-react"
import type { Contact, CheckInTimer, AppMode, EmergencySession, LocationData, WeatherData } from "./types"

// Utility debounce function
const debounce = (func: (...args: any[]) => void, delay: number) => {
  let timeout: NodeJS.Timeout
  return (...args: any[]) => {
    clearTimeout(timeout)
    timeout = setTimeout(() => func(...args), delay)
  }
}

export default function EmergencyFriendApp() {
  const [currentMode, setCurrentMode] = useState<AppMode>("dashboard")
  const [isEmergencyActive, setIsEmergencyActive] = useState(false)
  const [emergencyStartTime, setEmergencyStartTime] = useState<Date | null>(null)
  const [isIncognitoMode, setIsIncognitoMode] = useState(false)
  const [isDisguiseMode, setIsDisguiseMode] = useState(false)
  const [isDarkMode, setIsDarkMode] = useState(false)

  // New states for location and weather
  const [currentLocation, setCurrentLocation] = useState<LocationData | null>(null)
  const [currentWeather, setCurrentWeather] = useState<WeatherData | null>(null)
  const [locationError, setLocationError] = useState<string | null>(null)

  // Use ref to store watch ID to avoid stale closure issues
  const watchIdRef = useRef<number | null>(null)

  // Effect to apply dark mode class to body
  useEffect(() => {
    if (isDarkMode) {
      document.body.classList.add("dark")
    } else {
      document.body.classList.remove("dark")
    }
  }, [isDarkMode])

  // Memoize the debounced reverse geocoding function
  const debouncedReverseGeocode = useCallback(
    debounce(async (latitude: number, longitude: number, timestamp: number) => {
      try {
        const geoResponse = await fetch(
          `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${latitude}&lon=${longitude}`,
        )
        if (!geoResponse.ok) {
          const errorBody = await geoResponse.text()
          throw new Error(
            `Nominatim API HTTP error: ${geoResponse.status} ${geoResponse.statusText}. Response: ${errorBody}`,
          )
        }
        const geoData = await geoResponse.json()
        const address = geoData.display_name || `Lat: ${latitude}, Lng: ${longitude}`
        setCurrentLocation({ lat: latitude, lng: longitude, address, timestamp })
        setLocationError(null)
      } catch (error) {
        console.error("Network or parsing error fetching address from Nominatim:", error)
        setLocationError(
          `Could not fetch address: ${error instanceof Error ? error.message : String(error)}. Check console for details.`,
        )
        setCurrentLocation((prev) => ({
          lat: latitude,
          lng: longitude,
          address: prev?.address || `Lat: ${latitude}, Lng: ${longitude}`,
          timestamp,
        }))
      }
    }, 1000),
    [setCurrentLocation, setLocationError],
  )

  // Geolocation success handler
  const successHandler = useCallback(
    (position: GeolocationPosition) => {
      const { latitude, longitude } = position.coords
      const timestamp = position.timestamp
      setCurrentLocation((prev) => ({
        lat: latitude,
        lng: longitude,
        address: prev?.address || `Lat: ${latitude}, Lng: ${longitude}`,
        timestamp,
      }))
      debouncedReverseGeocode(latitude, longitude, timestamp)
    },
    [setCurrentLocation, debouncedReverseGeocode],
  )

  // Geolocation error handler
  const errorHandler = useCallback(
    (error: GeolocationPositionError) => {
      let errorMessage = "Unknown location error."
      switch (error.code) {
        case error.PERMISSION_DENIED:
          errorMessage = "Location access denied. Please enable it in your browser settings."
          break
        case error.POSITION_UNAVAILABLE:
          errorMessage = "Location information is unavailable. Try moving to an open area."
          break
        case error.TIMEOUT:
          errorMessage = "Location request timed out. Ensure good GPS signal or try again."
          break
        default:
          errorMessage = `Geolocation error: ${error.message || error.code}`
      }
      setLocationError(errorMessage)
      console.error("Geolocation error:", error)
    },
    [setLocationError],
  )

  // Effect to start watching geolocation
  useEffect(() => {
    if (!navigator.geolocation) {
      setLocationError("Geolocation is not supported by your browser.")
      return
    }

    if (typeof navigator.geolocation.watchPosition !== "function") {
      setLocationError("Geolocation watchPosition is not supported.")
      return
    }

    try {
      const watchId = navigator.geolocation.watchPosition(successHandler, errorHandler, {
        enableHighAccuracy: true,
        timeout: 15000, // Increased timeout to 15 seconds
        maximumAge: 0,
      })

      watchIdRef.current = watchId

      return () => {
        if (
          watchIdRef.current !== null &&
          navigator.geolocation &&
          typeof navigator.geolocation.clearWatch === "function"
        ) {
          try {
            navigator.geolocation.clearWatch(watchIdRef.current)
          } catch (error) {
            console.warn("Error clearing geolocation watch:", error)
          }
          watchIdRef.current = null
        }
      }
    } catch (error) {
      console.error("Error setting up geolocation watch:", error)
      setLocationError("Failed to start location tracking.")
    }
  }, [successHandler, errorHandler])

  // Fetch weather data when location changes
  useEffect(() => {
    const fetchWeather = async () => {
      if (!currentLocation) return

      const OPENWEATHER_API_KEY = process.env.NEXT_PUBLIC_OPENWEATHER_API_KEY
      if (!OPENWEATHER_API_KEY) {
        console.warn("OpenWeatherMap API key is not set. Weather data will not be available.")
        setCurrentWeather(null)
        return
      }

      try {
        const weatherResponse = await fetch(
          `https://api.openweathermap.org/data/2.5/weather?lat=${currentLocation.lat}&lon=${currentLocation.lng}&appid=${OPENWEATHER_API_KEY}&units=imperial`,
        )
        if (!weatherResponse.ok) {
          throw new Error(`Weather API error: ${weatherResponse.statusText}`)
        }
        const weatherData = await weatherResponse.json()

        setCurrentWeather({
          temp: Math.round(weatherData.main.temp),
          condition: weatherData.weather[0].description,
          icon: weatherData.weather[0].icon,
          alert: weatherData.alerts && weatherData.alerts.length > 0,
          city: weatherData.name,
          country: weatherData.sys.country,
        })
      } catch (error) {
        console.error("Error fetching weather:", error)
        setCurrentWeather(null)
      }
    }

    const handler = setTimeout(() => {
      fetchWeather()
    }, 500)

    return () => clearTimeout(handler)
  }, [currentLocation])

  const [contacts, setContacts] = useState<Contact[]>([
    {
      id: "1",
      name: "Sarah Johnson",
      phone: "+1 (555) 123-4567",
      email: "sarah@example.com",
      role: "primary",
    },
    {
      id: "2",
      name: "Mike Chen",
      phone: "+1 (555) 987-6543",
      role: "backup",
    },
    {
      id: "3",
      name: "Dr. Emily Rodriguez",
      phone: "+1 (555) 456-7890",
      email: "dr.rodriguez@hospital.com",
      role: "professional",
    },
  ])

  const [checkInTimer, setCheckInTimer] = useState<CheckInTimer | null>(null)
  const [incidents, setIncidents] = useState<EmergencySession[]>([
    {
      id: "1",
      startTime: new Date(Date.now() - 86400000),
      endTime: new Date(Date.now() - 86400000 + 1800000),
      location: { lat: 40.7128, lng: -74.006, address: "123 Main St, New York, NY" },
      recordings: ["video_001.mp4", "audio_001.wav"],
      transcript: [
        "Emergency activated at 9:15 PM",
        "User said: 'I need help, someone is following me'",
        "Location shared with 3 contacts",
        "Recording started - front camera",
        "AI detected elevated stress in voice",
        "Contact Sarah Johnson called back",
        "User confirmed safe at 9:45 PM",
      ],
      status: "resolved",
      alertsSent: ["Sarah Johnson", "Mike Chen", "Dr. Emily Rodriguez"],
    },
    {
      id: "2",
      startTime: new Date(Date.now() - 172800000),
      endTime: new Date(Date.now() - 172800000 + 900000),
      location: { lat: 40.7589, lng: -73.9851, address: "456 Park Ave, New York, NY" },
      recordings: ["video_002.mp4", "audio_002.wav"],
      transcript: [
        "Check-in timer expired at 11:30 PM",
        "Auto-alert sent to primary contacts",
        "No response from user for 5 minutes",
        "Emergency protocol activated",
        "User responded: 'Sorry, phone was on silent, I'm safe'",
      ],
      status: "resolved",
      alertsSent: ["Sarah Johnson", "Mike Chen"],
    },
  ])

  const [scenarioSettings, setScenarioSettings] = useState<{ duration: number; message: string } | null>(null)

  const handleEmergencyActivate = useCallback(() => {
    console.log("Emergency activated!")
    setIsEmergencyActive(true)
    setEmergencyStartTime(new Date())
    setCurrentMode("emergency")
    setIsIncognitoMode(false)
    setIsDisguiseMode(false)
  }, [])

  const handleEmergencyDeactivate = useCallback(() => {
    console.log("Emergency deactivated!")
    if (emergencyStartTime && currentLocation) {
      const newIncident: EmergencySession = {
        id: Date.now().toString(),
        startTime: emergencyStartTime,
        endTime: new Date(),
        location: currentLocation,
        recordings: [`video_${Date.now()}.mp4`, `audio_${Date.now()}.wav`],
        transcript: [
          "Emergency mode activated",
          "Recording started",
          "Location shared with contacts",
          "User marked safe",
        ],
        status: "resolved",
        alertsSent: contacts.filter((c) => c.role === "primary" || c.role === "backup").map((c) => c.name),
      }
      setIncidents((prev) => [newIncident, ...prev])
    }

    setIsEmergencyActive(false)
    setEmergencyStartTime(null)
    setCurrentMode("dashboard")
  }, [emergencyStartTime, currentLocation, contacts])

  const handleAddContact = useCallback((contactData: Omit<Contact, "id">) => {
    const newContact: Contact = {
      ...contactData,
      id: Date.now().toString(),
    }
    setContacts((prev) => [...prev, newContact])
  }, [])

  const handleUpdateContact = useCallback((id: string, updates: Partial<Contact>) => {
    setContacts((prev) => prev.map((contact) => (contact.id === id ? { ...contact, ...updates } : contact)))
  }, [])

  const handleDeleteContact = useCallback((id: string) => {
    setContacts((prev) => prev.filter((contact) => contact.id !== id))
  }, [])

  const handleStartTimer = useCallback((timerData: Omit<CheckInTimer, "id" | "isActive">) => {
    const newTimer: CheckInTimer = {
      ...timerData,
      id: Date.now().toString(),
      isActive: true,
    }
    setCheckInTimer(newTimer)
  }, [])

  const handleStopTimer = useCallback(() => {
    if (checkInTimer && currentLocation) {
      const newIncident: EmergencySession = {
        id: Date.now().toString(),
        startTime: new Date(),
        endTime: new Date(),
        location: currentLocation,
        recordings: [],
        transcript: [
          `Check-in timer expired: ${checkInTimer.message}`,
          "Auto-alerts sent to emergency contacts",
          "Awaiting user response",
        ],
        status: "active",
        alertsSent: contacts.filter((c) => c.role === "primary").map((c) => c.name),
      }
      setIncidents((prev) => [newIncident, ...prev])
      setCheckInTimer({ ...checkInTimer, isActive: false })
    }
  }, [checkInTimer, currentLocation, contacts])

  const handleCancelTimer = useCallback(() => {
    setCheckInTimer(null)
  }, [])

  const handleExportEvidence = useCallback(
    (incidentId: string) => {
      const incident = incidents.find((i) => i.id === incidentId)
      if (incident) {
        const dataStr = JSON.stringify(incident, null, 2)
        const dataUri = "data:application/json;charset=utf-8," + encodeURIComponent(dataStr)
        const exportFileDefaultName = `emergency_evidence_${incident.id}.json`

        const linkElement = document.createElement("a")
        linkElement.setAttribute("href", dataUri)
        linkElement.setAttribute("download", exportFileDefaultName)
        linkElement.click()
      }
    },
    [incidents],
  )

  const handleDeleteIncident = useCallback((incidentId: string) => {
    setIncidents((prev) => prev.filter((incident) => incident.id !== incidentId))
  }, [])

  const handleToggleIncognito = useCallback(() => {
    console.log("Toggling incognito mode")
    setIsIncognitoMode(!isIncognitoMode)
    setIsDisguiseMode(false)
  }, [isIncognitoMode])

  const handleToggleDisguise = useCallback(() => {
    console.log("Toggling disguise mode")
    setIsDisguiseMode(!isDisguiseMode)
    setIsIncognitoMode(false)
  }, [isDisguiseMode])

  const handleExitIncognito = useCallback(() => {
    setIsIncognitoMode(false)
    setCurrentMode("dashboard")
  }, [])

  const handleExitDisguise = useCallback(() => {
    setIsDisguiseMode(false)
    setCurrentMode("dashboard")
  }, [])

  const handleToggleDarkMode = useCallback((checked: boolean) => {
    console.log("Dark mode:", checked)
    setIsDarkMode(checked)
  }, [])

  const handleNavigate = useCallback((mode: string, scenarioData?: { duration: number; message: string }) => {
    console.log("Navigating to:", mode, scenarioData)
    setCurrentMode(mode as AppMode)
    if (scenarioData) {
      setScenarioSettings(scenarioData)
    }
  }, [])

  // Disguise Mode - Show fake calculator
  if (isDisguiseMode) {
    return <DisguiseMode onExitDisguise={handleExitDisguise} onEmergencyActivate={handleEmergencyActivate} />
  }

  const renderContent = () => {
    switch (currentMode) {
      case "emergency":
        return emergencyStartTime ? (
          <EmergencyMode onDeactivate={handleEmergencyDeactivate} startTime={emergencyStartTime} />
        ) : null

      case "contacts":
        return (
          <ContactManager
            contacts={contacts}
            onAddContact={handleAddContact}
            onUpdateContact={handleUpdateContact}
            onDeleteContact={handleDeleteContact}
          />
        )

      case "timer":
        return (
          <CheckInTimerComponent
            timer={checkInTimer}
            onStartTimer={handleStartTimer}
            onStopTimer={handleStopTimer}
            onCancelTimer={handleCancelTimer}
            scenarioSettings={scenarioSettings}
            onClearScenario={() => setScenarioSettings(null)}
          />
        )

      case "evidence":
        return (
          <EvidenceVault
            incidents={incidents}
            onExportEvidence={handleExportEvidence}
            onDeleteIncident={handleDeleteIncident}
          />
        )

      case "settings":
        return (
          <Settings
            onToggleIncognito={handleToggleIncognito}
            onToggleDisguise={handleToggleDisguise}
            isIncognitoMode={isIncognitoMode}
            isDisguiseMode={isDisguiseMode}
            onToggleDarkMode={handleToggleDarkMode}
            isDarkMode={isDarkMode}
          />
        )

      case "dashboard":
      default:
        return (
          <div className="space-y-8">
            <div className="text-center">
              <EmergencyButton onActivate={handleEmergencyActivate} isActive={isEmergencyActive} />
            </div>
            <Dashboard
              contactCount={contacts.length}
              onNavigate={handleNavigate}
              currentLocation={currentLocation}
              currentWeather={currentWeather}
              locationError={locationError}
            />
          </div>
        )
    }
  }

  if (currentMode === "emergency") {
    return renderContent()
  }

  return (
    <div className="min-h-screen relative">
      {/* Star Background */}
      <div className="star-background" />

      {/* Incognito Mode Overlay */}
      {isIncognitoMode && (
        <IncognitoMode onExitIncognito={handleExitIncognito} onEmergencyActivate={handleEmergencyActivate} />
      )}

      {/* Header */}
      <div className="bg-background/95 backdrop-blur-sm shadow-sm border-b relative z-10">
        <div className="max-w-md mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            {currentMode !== "dashboard" && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  console.log("Back button clicked")
                  setCurrentMode("dashboard")
                }}
                className="flex items-center space-x-1"
              >
                <ArrowLeft size={16} />
                <span>Back</span>
              </Button>
            )}
            <h1 className="text-lg font-semibold text-foreground">Emergency Friend</h1>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                console.log("Settings button clicked")
                setCurrentMode("settings")
              }}
              className="flex items-center space-x-1"
            >
              <SettingsIcon size={16} />
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-md mx-auto p-4 pb-20 relative z-10 bg-background">{renderContent()}</div>

      {/* Bottom Navigation */}
      {currentMode !== "emergency" && !isIncognitoMode && (
        <div className="fixed bottom-0 left-0 right-0 bg-background/95 backdrop-blur-sm border-t z-20">
          <div className="max-w-md mx-auto">
            <div className="flex justify-around py-2">
              <Button
                variant={currentMode === "dashboard" ? "default" : "ghost"}
                size="sm"
                onClick={() => {
                  console.log("Home clicked")
                  setCurrentMode("dashboard")
                }}
                className="flex flex-col items-center space-y-1 h-auto py-2"
              >
                <Home size={20} />
                <span className="text-xs">Home</span>
              </Button>

              <Button
                variant={currentMode === "contacts" ? "default" : "ghost"}
                size="sm"
                onClick={() => {
                  console.log("Contacts clicked")
                  setCurrentMode("contacts")
                }}
                className="flex flex-col items-center space-y-1 h-auto py-2"
              >
                <Users size={20} />
                <span className="text-xs">Contacts</span>
              </Button>

              <Button
                variant={currentMode === "timer" ? "default" : "ghost"}
                size="sm"
                onClick={() => {
                  console.log("Timer clicked")
                  setCurrentMode("timer")
                }}
                className="flex flex-col items-center space-y-1 h-auto py-2"
              >
                <Clock size={20} />
                <span className="text-xs">Timer</span>
              </Button>

              <Button
                variant={currentMode === "evidence" ? "default" : "ghost"}
                size="sm"
                onClick={() => {
                  console.log("Evidence clicked")
                  setCurrentMode("evidence")
                }}
                className="flex flex-col items-center space-y-1 h-auto py-2"
              >
                <Shield size={20} />
                <span className="text-xs">Evidence</span>
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
