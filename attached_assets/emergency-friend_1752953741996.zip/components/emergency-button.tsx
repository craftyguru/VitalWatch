"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { AlertTriangle, Phone, Video, MapPin } from "lucide-react"

interface EmergencyButtonProps {
  onActivate: () => void
  isActive: boolean
}

export function EmergencyButton({ onActivate, isActive }: EmergencyButtonProps) {
  const [pressTime, setPressTime] = useState(0)
  const [isPressed, setIsPressed] = useState(false)

  useEffect(() => {
    let interval: NodeJS.Timeout
    if (isPressed && !isActive) {
      interval = setInterval(() => {
        setPressTime((prev) => {
          if (prev >= 3000) {
            // Defer the onActivate call to the next event loop tick
            setTimeout(() => onActivate(), 0)
            setIsPressed(false)
            return 0
          }
          return prev + 100
        })
      }, 100)
    } else {
      setPressTime(0)
    }

    return () => clearInterval(interval)
  }, [isPressed, isActive, onActivate])

  const handleMouseDown = () => {
    if (!isActive) {
      setIsPressed(true)
    }
  }

  const handleMouseUp = () => {
    setIsPressed(false)
    setPressTime(0)
  }

  const progress = (pressTime / 3000) * 100

  return (
    <div className="flex flex-col items-center space-y-4">
      <div className="relative">
        <Button
          size="lg"
          className={`w-48 h-48 rounded-full text-white font-bold text-xl transition-all duration-200 ${
            isActive ? "bg-green-600 hover:bg-green-700 animate-pulse" : "bg-red-600 hover:bg-red-700 active:scale-95"
          }`}
          onMouseDown={handleMouseDown}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          onTouchStart={handleMouseDown}
          onTouchEnd={handleMouseUp}
          disabled={isActive}
        >
          <div className="flex flex-col items-center space-y-2">
            <AlertTriangle size={48} />
            {isActive ? "EMERGENCY ACTIVE" : "EMERGENCY"}
          </div>
        </Button>

        {isPressed && !isActive && (
          <div className="absolute inset-0 rounded-full border-4 border-white">
            <div
              className="absolute inset-0 rounded-full bg-white opacity-30 transition-all duration-100"
              style={{
                clipPath: `polygon(50% 50%, 50% 0%, ${50 + (progress / 100) * 50}% 0%, ${50 + (progress / 100) * 50}% 100%, 50% 100%)`,
              }}
            />
          </div>
        )}
      </div>

      <div className="text-center space-y-2">
        {isActive ? (
          <div className="flex items-center space-x-4 text-green-600">
            <div className="flex items-center space-x-1">
              <Video size={16} />
              <span className="text-sm">Recording</span>
            </div>
            <div className="flex items-center space-x-1">
              <MapPin size={16} />
              <span className="text-sm">Tracking</span>
            </div>
            <div className="flex items-center space-x-1">
              <Phone size={16} />
              <span className="text-sm">Alerts Sent</span>
            </div>
          </div>
        ) : (
          <p className="text-sm text-gray-600">Hold for 3 seconds to activate emergency mode</p>
        )}
      </div>
    </div>
  )
}
