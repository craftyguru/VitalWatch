"use client"

import { useState, useEffect, useRef, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Video, VideoOff, Mic, MicOff, MapPin, Phone, Square, Users, FileText } from "lucide-react"

interface EmergencyModeProps {
  onDeactivate: () => void
  startTime: Date
}

export function EmergencyMode({ onDeactivate, startTime }: EmergencyModeProps) {
  const [isRecording, setIsRecording] = useState(true) // Video recording state
  const [isMicOn, setIsMicOn] = useState(true) // Microphone state
  const [elapsedTime, setElapsedTime] = useState(0)
  const [transcript, setTranscript] = useState<string[]>([
    "Emergency mode activated",
    "Location shared with 3 contacts",
    "Recording started",
  ])

  const mediaRecorderRef = useRef<MediaRecorder | null>(null)
  const audioChunksRef = useRef<Blob[]>([])
  const transcriptIntervalRef = useRef<NodeJS.Timeout | null>(null)

  // Function to send audio chunks to the API
  const sendAudioChunk = useCallback(async (chunk: Blob) => {
    try {
      const response = await fetch("/api/ai-witness", {
        method: "POST",
        body: chunk,
        headers: {
          "Content-Type": "audio/webm", // Or appropriate audio MIME type
        },
      })

      if (!response.ok) {
        throw new Error(`API error: ${response.statusText}`)
      }

      const data = await response.json()
      if (data.success && data.transcript) {
        setTranscript((prev) => {
          const newTranscript = [...prev, data.transcript]
          // Keep transcript length manageable, e.g., last 10 entries
          return newTranscript.slice(Math.max(0, newTranscript.length - 10))
        })
      } else if (data.error) {
        console.error("AI Witness API returned error:", data.error)
        setTranscript((prev) => [...prev, `Error: ${data.error}`])
      }
    } catch (error) {
      console.error("Failed to send audio chunk:", error)
      setTranscript((prev) => [...prev, `Network Error: ${error instanceof Error ? error.message : String(error)}`])
    }
  }, [])

  // Effect for elapsed time and AI transcript simulation
  useEffect(() => {
    const timerInterval = setInterval(() => {
      setElapsedTime(Date.now() - startTime.getTime())
    }, 1000)

    // Clear previous transcript interval if it exists
    if (transcriptIntervalRef.current) {
      clearInterval(transcriptIntervalRef.current)
    }

    // Start microphone and AI processing if mic is on
    if (isMicOn) {
      // Request microphone access
      navigator.mediaDevices
        .getUserMedia({ audio: true })
        .then((stream) => {
          mediaRecorderRef.current = new MediaRecorder(stream, { mimeType: "audio/webm" }) // Use webm for broader compatibility

          mediaRecorderRef.current.ondataavailable = (event) => {
            if (event.data.size > 0) {
              audioChunksRef.current.push(event.data)
              // Send chunks periodically, e.g., every 1 second of audio
              if (audioChunksRef.current.length > 0) {
                const combinedBlob = new Blob(audioChunksRef.current, { type: "audio/webm" })
                sendAudioChunk(combinedBlob)
                audioChunksRef.current = [] // Clear chunks after sending
              }
            }
          }

          mediaRecorderRef.current.onstop = () => {
            stream.getTracks().forEach((track) => track.stop()) // Stop all tracks
            console.log("MediaRecorder stopped. Audio stream closed.")
          }

          mediaRecorderRef.current.start(1000) // Start recording, collect data every 1 second
          console.log("MediaRecorder started.")

          // Simulate AI transcript updates (in addition to real audio processing)
          transcriptIntervalRef.current = setInterval(() => {
            const sampleTranscripts = [
              "AI: 'Analyzing background noise.'",
              "AI: 'User activity detected.'",
              "AI: 'Location updated: Moving north.'",
              "AI: 'Voice stress level: Stable.'",
            ]
            const randomTranscript = sampleTranscripts[Math.floor(Math.random() * sampleTranscripts.length)]
            setTranscript((prev) => {
              const newTranscript = [...prev, `${new Date().toLocaleTimeString()}: ${randomTranscript}`]
              return newTranscript.slice(Math.max(0, newTranscript.length - 10)) // Keep last 10
            })
          }, 5000) // Add a simulated transcript every 5 seconds
        })
        .catch((err) => {
          console.error("Error accessing microphone:", err)
          setIsMicOn(false) // Turn off mic state if access fails
          setTranscript((prev) => [...prev, `Microphone access denied or error: ${err.message}`])
        })
    } else {
      // If mic is off, stop media recorder and clear interval
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== "inactive") {
        mediaRecorderRef.current.stop()
      }
      if (transcriptIntervalRef.current) {
        clearInterval(transcriptIntervalRef.current)
      }
    }

    return () => {
      clearInterval(timerInterval)
      if (transcriptIntervalRef.current) {
        clearInterval(transcriptIntervalRef.current)
      }
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== "inactive") {
        mediaRecorderRef.current.stop()
      }
    }
  }, [startTime, isMicOn, sendAudioChunk]) // Re-run effect when isMicOn changes

  const formatElapsedTime = (ms: number) => {
    const minutes = Math.floor(ms / 60000)
    const seconds = Math.floor((ms % 60000) / 1000)
    return `${minutes}:${seconds.toString().padStart(2, "0")}`
  }

  const handleToggleMic = () => {
    setIsMicOn((prev) => !prev)
  }

  return (
    <div className="min-h-screen bg-red-50 p-4">
      <div className="max-w-md mx-auto space-y-4">
        {/* Header */}
        <Card className="bg-red-600 text-white">
          <CardContent className="p-4 text-center">
            <h1 className="text-xl font-bold">EMERGENCY MODE ACTIVE</h1>
            <p className="text-red-100">Duration: {formatElapsedTime(elapsedTime)}</p>
          </CardContent>
        </Card>

        {/* Status Cards */}
        <div className="grid grid-cols-2 gap-2">
          <Card>
            <CardContent className="p-3 text-center">
              <Video className={`mx-auto mb-1 ${isRecording ? "text-red-600" : "text-gray-400"}`} size={24} />
              <p className="text-xs font-semibold">Recording</p>
              <Badge variant={isRecording ? "destructive" : "secondary"}>{isRecording ? "ON" : "OFF"}</Badge>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-3 text-center">
              <MapPin className="mx-auto mb-1 text-blue-600" size={24} />
              <p className="text-xs font-semibold">Location</p>
              <Badge className="bg-blue-600">SHARING</Badge>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-3 text-center">
              <Users className="mx-auto mb-1 text-green-600" size={24} />
              <p className="text-xs font-semibold">Contacts</p>
              <Badge className="bg-green-600">3 ALERTED</Badge>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-3 text-center">
              <FileText className="mx-auto mb-1 text-purple-600" size={24} />
              <p className="text-xs font-semibold">AI Witness</p>
              <Badge className="bg-purple-600">{isMicOn ? "ACTIVE" : "INACTIVE"}</Badge>
            </CardContent>
          </Card>
        </div>

        {/* Controls */}
        <Card>
          <CardContent className="p-4">
            <div className="grid grid-cols-2 gap-2 mb-4">
              <Button
                variant={isRecording ? "destructive" : "outline"}
                onClick={() => setIsRecording(!isRecording)}
                className="flex items-center space-x-2"
              >
                {isRecording ? <VideoOff size={16} /> : <Video size={16} />}
                <span>{isRecording ? "Stop" : "Start"} Video</span>
              </Button>

              <Button
                variant={isMicOn ? "destructive" : "outline"}
                onClick={handleToggleMic}
                className="flex items-center space-x-2"
              >
                {isMicOn ? <MicOff size={16} /> : <Mic size={16} />}
                <span>{isMicOn ? "Mute" : "Unmute"} Mic</span>
              </Button>
            </div>

            <Button
              onClick={onDeactivate}
              className="w-full bg-green-600 hover:bg-green-700 flex items-center justify-center space-x-2"
            >
              <Square size={16} />
              <span>I'm Safe - End Emergency</span>
            </Button>
          </CardContent>
        </Card>

        {/* AI Transcript */}
        <Card>
          <CardContent className="p-4">
            <h3 className="font-semibold mb-2 flex items-center space-x-2">
              <FileText size={16} />
              <span>AI Witness Transcript</span>
            </h3>
            <div className="bg-gray-50 p-3 rounded-lg max-h-40 overflow-y-auto">
              {transcript.map((entry, index) => (
                <p key={index} className="text-xs text-gray-700 mb-1">
                  {entry}
                </p>
              ))}
            </div>
            <p className="text-xs text-gray-500 mt-2">
              Note: This transcript is simulated. Real-time audio processing requires microphone access and a backend
              STT service.
            </p>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardContent className="p-4">
            <h3 className="font-semibold mb-2">Quick Actions</h3>
            <div className="space-y-2">
              <Button variant="outline" className="w-full justify-start bg-transparent">
                <Phone size={16} className="mr-2" />
                Call 911
              </Button>
              <Button variant="outline" className="w-full justify-start bg-transparent">
                <MapPin size={16} className="mr-2" />
                Share Exact Location
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
