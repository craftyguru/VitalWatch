"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Video,
  MapPin,
  Download,
  Search,
  Filter,
  Trash2,
  Share,
  Lock,
  Clock,
  Users,
  Archive,
  Cloud,
} from "lucide-react"
import type { EmergencySession } from "../types"

interface EvidenceVaultProps {
  incidents: EmergencySession[]
  onExportEvidence: (incidentId: string) => void
  onDeleteIncident: (incidentId: string) => void
}

export function EvidenceVault({ incidents, onExportEvidence, onDeleteIncident }: EvidenceVaultProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [filterStatus, setFilterStatus] = useState<string>("all")
  const [selectedIncident, setSelectedIncident] = useState<EmergencySession | null>(null)

  const filteredIncidents = incidents.filter((incident) => {
    const matchesSearch =
      incident.location.address.toLowerCase().includes(searchTerm.toLowerCase()) ||
      incident.transcript.some((t) => t.toLowerCase().includes(searchTerm.toLowerCase()))
    const matchesFilter = filterStatus === "all" || incident.status === filterStatus
    return matchesSearch && matchesFilter
  })

  const getStatusColor = (status: EmergencySession["status"]) => {
    switch (status) {
      case "active":
        return "bg-red-600"
      case "resolved":
        return "bg-green-600"
      case "cancelled":
        return "bg-gray-600"
      default:
        return "bg-blue-600"
    }
  }

  const formatDuration = (start: Date, end?: Date) => {
    if (!end) return "Ongoing"
    const duration = end.getTime() - start.getTime()
    const minutes = Math.floor(duration / 60000)
    const seconds = Math.floor((duration % 60000) / 1000)
    return `${minutes}m ${seconds}s`
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Evidence Vault</h2>
        <div className="flex items-center space-x-2">
          <Badge className="bg-green-600">
            <Lock size={12} className="mr-1" />
            Encrypted
          </Badge>
        </div>
      </div>

      {/* Storage Status */}
      <Card>
        <CardContent className="p-4">
          <div className="flex justify-between items-center mb-2">
            <h3 className="font-semibold">Storage Status</h3>
            <Badge className="bg-blue-600">
              <Cloud size={12} className="mr-1" />
              Auto-Backup ON
            </Badge>
          </div>
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <p className="text-2xl font-bold text-blue-600">{incidents.length}</p>
              <p className="text-xs text-gray-600">Total Incidents</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-green-600">2.4GB</p>
              <p className="text-xs text-gray-600">Evidence Stored</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-purple-600">100%</p>
              <p className="text-xs text-gray-600">Backup Complete</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Search and Filter */}
      <Card>
        <CardContent className="p-4 space-y-3">
          <div className="flex space-x-2">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
              <Input
                placeholder="Search incidents, locations, transcripts..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-32">
                <Filter size={16} className="mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="resolved">Resolved</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Incidents List */}
      <div className="space-y-3">
        {filteredIncidents.map((incident) => (
          <Card key={incident.id} className="cursor-pointer hover:shadow-md transition-shadow">
            <CardContent className="p-4">
              <div className="flex justify-between items-start mb-3">
                <div className="flex items-center space-x-2">
                  <Badge className={getStatusColor(incident.status)}>{incident.status.toUpperCase()}</Badge>
                  <span className="text-sm text-gray-600">
                    {incident.startTime.toLocaleDateString()} at {incident.startTime.toLocaleTimeString()}
                  </span>
                </div>
                <Button size="sm" variant="outline" onClick={() => setSelectedIncident(incident)}>
                  View Details
                </Button>
              </div>

              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="flex items-center space-x-2">
                  <MapPin size={14} className="text-blue-600" />
                  <span className="truncate">{incident.location.address}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Clock size={14} className="text-green-600" />
                  <span>Duration: {formatDuration(incident.startTime, incident.endTime)}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Video size={14} className="text-purple-600" />
                  <span>{incident.recordings.length} recordings</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Users size={14} className="text-orange-600" />
                  <span>{incident.alertsSent.length} contacts alerted</span>
                </div>
              </div>

              <div className="flex justify-between items-center mt-3 pt-3 border-t">
                <div className="flex space-x-2">
                  <Button size="sm" variant="outline" onClick={() => onExportEvidence(incident.id)}>
                    <Download size={14} className="mr-1" />
                    Export
                  </Button>
                  <Button size="sm" variant="outline">
                    <Share size={14} className="mr-1" />
                    Share
                  </Button>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => onDeleteIncident(incident.id)}
                  className="text-red-600 hover:text-red-700"
                >
                  <Trash2 size={14} />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredIncidents.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <Archive size={48} className="mx-auto mb-4 text-gray-400" />
            <h3 className="text-lg font-semibold mb-2">No Evidence Found</h3>
            <p className="text-gray-600">
              {searchTerm || filterStatus !== "all"
                ? "No incidents match your search criteria"
                : "Your evidence vault is empty"}
            </p>
          </CardContent>
        </Card>
      )}

      {/* Incident Detail Modal */}
      {selectedIncident && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>Incident Details</CardTitle>
                <Button variant="outline" onClick={() => setSelectedIncident(null)}>
                  Close
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <Tabs defaultValue="overview">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="overview">Overview</TabsTrigger>
                  <TabsTrigger value="location">Location</TabsTrigger>
                  <TabsTrigger value="recordings">Media</TabsTrigger>
                  <TabsTrigger value="transcript">Transcript</TabsTrigger>
                </TabsList>

                <TabsContent value="overview" className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-sm font-semibold">Status</Label>
                      <Badge className={getStatusColor(selectedIncident.status)}>
                        {selectedIncident.status.toUpperCase()}
                      </Badge>
                    </div>
                    <div>
                      <Label className="text-sm font-semibold">Duration</Label>
                      <p>{formatDuration(selectedIncident.startTime, selectedIncident.endTime)}</p>
                    </div>
                    <div>
                      <Label className="text-sm font-semibold">Start Time</Label>
                      <p>{selectedIncident.startTime.toLocaleString()}</p>
                    </div>
                    <div>
                      <Label className="text-sm font-semibold">End Time</Label>
                      <p>{selectedIncident.endTime?.toLocaleString() || "Ongoing"}</p>
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm font-semibold">Contacts Alerted</Label>
                    <div className="flex flex-wrap gap-2 mt-1">
                      {selectedIncident.alertsSent.map((contact, index) => (
                        <Badge key={index} variant="secondary">
                          {contact}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="location" className="space-y-4">
                  <div>
                    <Label className="text-sm font-semibold">Address</Label>
                    <p className="mt-1">{selectedIncident.location.address}</p>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-sm font-semibold">Latitude</Label>
                      <p>{selectedIncident.location.lat}</p>
                    </div>
                    <div>
                      <Label className="text-sm font-semibold">Longitude</Label>
                      <p>{selectedIncident.location.lng}</p>
                    </div>
                  </div>
                  <div className="bg-gray-100 p-4 rounded-lg text-center">
                    <MapPin size={48} className="mx-auto mb-2 text-blue-600" />
                    <p className="text-sm text-gray-600">Interactive map would appear here</p>
                  </div>
                </TabsContent>

                <TabsContent value="recordings" className="space-y-4">
                  <div>
                    <Label className="text-sm font-semibold">Recorded Files</Label>
                    <div className="space-y-2 mt-2">
                      {selectedIncident.recordings.map((recording, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center space-x-2">
                            <Video size={16} className="text-purple-600" />
                            <span className="text-sm">{recording}</span>
                          </div>
                          <Button size="sm" variant="outline">
                            <Download size={14} className="mr-1" />
                            Download
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="transcript" className="space-y-4">
                  <div>
                    <Label className="text-sm font-semibold">AI Transcript</Label>
                    <div className="bg-gray-50 p-4 rounded-lg max-h-60 overflow-y-auto mt-2">
                      {selectedIncident.transcript.map((entry, index) => (
                        <p key={index} className="text-sm mb-2 p-2 bg-white rounded border-l-4 border-blue-500">
                          {entry}
                        </p>
                      ))}
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}

function Label({ children, className }: { children: React.ReactNode; className?: string }) {
  return <label className={className}>{children}</label>
}
