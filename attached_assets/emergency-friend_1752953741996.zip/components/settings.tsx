"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { SettingsIcon, Shield, Bell, Lock, Eye, Sun, Trash2, Download, Upload } from "lucide-react"

interface SettingsProps {
  onToggleIncognito: () => void
  onToggleDisguise: () => void
  isIncognitoMode: boolean
  isDisguiseMode: boolean
  onToggleDarkMode: (isDark: boolean) => void // New prop
  isDarkMode: boolean // New prop
}

export function Settings({
  onToggleIncognito,
  onToggleDisguise,
  isIncognitoMode,
  isDisguiseMode,
  onToggleDarkMode,
  isDarkMode,
}: SettingsProps) {
  const [settings, setSettings] = useState({
    // Privacy & Security
    autoRecord: true,
    locationSharing: true,
    cloudBackup: true,
    biometricLock: false,

    // Notifications
    pushNotifications: true,
    soundAlerts: true,
    vibrationAlerts: true,
    silentMode: false,

    // Emergency Settings
    emergencyTimeout: 3,
    autoCallPolice: false,
    recordingQuality: "high",
    batteryOptimization: true,

    // Appearance
    // darkMode: false, // Managed by parent now
    fontSize: "medium",

    // Advanced
    developerMode: false,
  })

  const updateSetting = (key: keyof typeof settings, value: any) => {
    setSettings((prev) => ({ ...prev, [key]: value }))
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Settings</h2>
        <SettingsIcon size={24} className="text-gray-600" />
      </div>

      {/* Stealth & Privacy */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Eye size={20} />
            <span>Stealth & Privacy</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <Label className="font-medium">Incognito Mode</Label>
              <p className="text-sm text-gray-600">Hide app in floating button</p>
            </div>
            <Switch checked={isIncognitoMode} onCheckedChange={onToggleIncognito} />
          </div>

          <div className="flex justify-between items-center">
            <div>
              <Label className="font-medium">Disguise Mode</Label>
              <p className="text-sm text-gray-600">Show fake calculator app</p>
            </div>
            <Switch checked={isDisguiseMode} onCheckedChange={onToggleDisguise} />
          </div>

          <div className="flex justify-between items-center">
            <div>
              <Label className="font-medium">Biometric Lock</Label>
              <p className="text-sm text-gray-600">Require fingerprint to open</p>
            </div>
            <Switch
              checked={settings.biometricLock}
              onCheckedChange={(value) => updateSetting("biometricLock", value)}
            />
          </div>

          <div className="flex justify-between items-center">
            <div>
              <Label className="font-medium">Cloud Backup</Label>
              <p className="text-sm text-gray-600">Encrypted evidence storage</p>
            </div>
            <Switch checked={settings.cloudBackup} onCheckedChange={(value) => updateSetting("cloudBackup", value)} />
          </div>
        </CardContent>
      </Card>

      {/* Emergency Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Shield size={20} />
            <span>Emergency Settings</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label className="font-medium">Emergency Button Timeout</Label>
            <p className="text-sm text-gray-600 mb-2">Seconds to hold before activation</p>
            <Slider
              value={[settings.emergencyTimeout]}
              onValueChange={(value) => updateSetting("emergencyTimeout", value[0])}
              max={10}
              min={1}
              step={1}
              className="w-full"
            />
            <p className="text-xs text-gray-500 mt-1">{settings.emergencyTimeout} seconds</p>
          </div>

          <div className="flex justify-between items-center">
            <div>
              <Label className="font-medium">Auto-Record</Label>
              <p className="text-sm text-gray-600">Start recording immediately</p>
            </div>
            <Switch checked={settings.autoRecord} onCheckedChange={(value) => updateSetting("autoRecord", value)} />
          </div>

          <div className="flex justify-between items-center">
            <div>
              <Label className="font-medium">Location Sharing</Label>
              <p className="text-sm text-gray-600">Share GPS with contacts</p>
            </div>
            <Switch
              checked={settings.locationSharing}
              onCheckedChange={(value) => updateSetting("locationSharing", value)}
            />
          </div>

          <div className="flex justify-between items-center">
            <div>
              <Label className="font-medium">Auto-Call Police</Label>
              <p className="text-sm text-gray-600">Call 911 after 30 seconds</p>
            </div>
            <Switch
              checked={settings.autoCallPolice}
              onCheckedChange={(value) => updateSetting("autoCallPolice", value)}
            />
          </div>

          <div>
            <Label className="font-medium">Recording Quality</Label>
            <Select
              value={settings.recordingQuality}
              onValueChange={(value) => updateSetting("recordingQuality", value)}
            >
              <SelectTrigger className="mt-2">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Low (saves battery)</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="high">High (best evidence)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Notifications */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Bell size={20} />
            <span>Notifications</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <Label className="font-medium">Push Notifications</Label>
              <p className="text-sm text-gray-600">Emergency alerts and updates</p>
            </div>
            <Switch
              checked={settings.pushNotifications}
              onCheckedChange={(value) => updateSetting("pushNotifications", value)}
            />
          </div>

          <div className="flex justify-between items-center">
            <div>
              <Label className="font-medium">Sound Alerts</Label>
              <p className="text-sm text-gray-600">Audio notifications</p>
            </div>
            <Switch checked={settings.soundAlerts} onCheckedChange={(value) => updateSetting("soundAlerts", value)} />
          </div>

          <div className="flex justify-between items-center">
            <div>
              <Label className="font-medium">Vibration</Label>
              <p className="text-sm text-gray-600">Haptic feedback</p>
            </div>
            <Switch
              checked={settings.vibrationAlerts}
              onCheckedChange={(value) => updateSetting("vibrationAlerts", value)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Appearance */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Sun size={20} />
            <span>Appearance</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <Label className="font-medium">Dark Mode</Label>
              <p className="text-sm text-gray-600">Use dark theme</p>
            </div>
            <Switch checked={isDarkMode} onCheckedChange={onToggleDarkMode} />
          </div>

          <div>
            <Label className="font-medium">Font Size</Label>
            <Select value={settings.fontSize} onValueChange={(value) => updateSetting("fontSize", value)}>
              <SelectTrigger className="mt-2">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="small">Small</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="large">Large</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Data Management */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Download size={20} />
            <span>Data Management</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Button variant="outline" className="w-full justify-start bg-transparent">
            <Download size={16} className="mr-2" />
            Export All Data
          </Button>

          <Button variant="outline" className="w-full justify-start bg-transparent">
            <Upload size={16} className="mr-2" />
            Import Settings
          </Button>

          <Button variant="outline" className="w-full justify-start text-red-600 hover:text-red-700 bg-transparent">
            <Trash2 size={16} className="mr-2" />
            Clear All Evidence
          </Button>
        </CardContent>
      </Card>

      {/* Advanced */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Lock size={20} />
            <span>Advanced</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <Label className="font-medium">Developer Mode</Label>
              <p className="text-sm text-gray-600">Enable debug features</p>
            </div>
            <Switch
              checked={settings.developerMode}
              onCheckedChange={(value) => updateSetting("developerMode", value)}
            />
          </div>

          <div className="flex justify-between items-center">
            <div>
              <Label className="font-medium">Battery Optimization</Label>
              <p className="text-sm text-gray-600">Reduce power consumption</p>
            </div>
            <Switch
              checked={settings.batteryOptimization}
              onCheckedChange={(value) => updateSetting("batteryOptimization", value)}
            />
          </div>
        </CardContent>
      </Card>

      {/* App Info */}
      <Card>
        <CardContent className="p-4 text-center text-sm text-gray-600">
          <p>Emergency Friend v2.1.0</p>
          <p>© 2024 Safety First Technologies</p>
          <div className="flex justify-center space-x-4 mt-2">
            <Button variant="link" size="sm">
              Privacy Policy
            </Button>
            <Button variant="link" size="sm">
              Terms of Service
            </Button>
            <Button variant="link" size="sm">
              Support
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
