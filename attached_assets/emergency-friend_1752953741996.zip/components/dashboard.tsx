"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Switch } from "@/components/ui/switch"
import {
  Shield,
  Clock,
  Users,
  MapPin,
  FileText,
  Settings,
  Phone,
  Battery,
  Wifi,
  CloudRain,
  AlertTriangle,
  Navigation,
  Heart,
  Car,
  Home,
  Briefcase,
  Moon,
  Sun,
  Volume2,
  VolumeX,
  Smartphone,
  Watch,
  Headphones,
  Camera,
  TrendingUp,
  Activity,
  Zap,
  Bell,
  WifiOff,
  Info,
} from "lucide-react"
import type { LocationData, WeatherData } from "../types"

interface DashboardProps {
  contactCount: number
  onNavigate: (mode: string, scenarioData?: { duration: number; message: string }) => void
  currentLocation: LocationData | null
  currentWeather: WeatherData | null
  locationError: string | null
}

export function Dashboard({
  contactCount,
  onNavigate,
  currentLocation,
  currentWeather,
  locationError,
}: DashboardProps) {
  const [batteryLevel, setBatteryLevel] = useState(85)
  const [isConnected, setIsConnected] = useState(true)
  const [quickSettings, setQuickSettings] = useState({
    silentMode: false,
    locationSharing: true,
    autoRecord: true,
    nightMode: false,
  })

  const recentActivity = [
    { time: "2 hours ago", action: "Check-in timer completed", status: "safe", location: "Home" },
    { time: "1 day ago", action: "Emergency contact added", status: "info", location: "Settings" },
    { time: "3 days ago", action: "Practice mode completed", status: "success", location: "Training" },
    { time: "1 week ago", action: "Location shared with contacts", status: "info", location: "Downtown" },
  ]

  const safetyScenarios = [
    { name: "First Date", icon: Heart, description: "Going on a first date", color: "bg-pink-600" },
    { name: "Rideshare", icon: Car, description: "Taking Uber/Lyft", color: "bg-blue-600" },
    { name: "Walking Home", icon: Home, description: "Walking alone at night", color: "bg-purple-600" },
    { name: "Business Trip", icon: Briefcase, description: "Traveling for work", color: "bg-green-600" },
    { name: "Late Night Out", icon: Moon, description: "Out late with friends", color: "bg-indigo-600" },
    { name: "Jogging", icon: Activity, description: "Running or exercising", color: "bg-orange-600" },
  ]

  const deviceStatus = [
    { name: "Phone", icon: Smartphone, status: "Connected", battery: batteryLevel, color: "text-green-600" },
    { name: "Watch", icon: Watch, status: "Connected", battery: 92, color: "text-green-600" },
    { name: "Earbuds", icon: Headphones, status: "Disconnected", battery: 0, color: "text-gray-400" },
  ]

  // Mock crime alerts - clearly labeled as sample data
  const crimeAlerts = [
    { type: "Theft", location: "0.3 miles away", time: "2 hours ago", severity: "medium" },
    { type: "Assault", location: "0.8 miles away", time: "1 day ago", severity: "high" },
  ]

  const safetyTips = [
    "Share your location when going to unfamiliar places",
    "Set check-in timers for dates and meetings",
    "Keep your emergency contacts updated",
    "Practice using the emergency button regularly",
    "Ensure your phone is charged before going out",
  ]

  const handleQuickSettingChange = (setting: keyof typeof quickSettings, checkedValue: boolean) => {
    setQuickSettings((prev) => ({ ...prev, [setting]: checkedValue }))

    // Provide user feedback for what each setting would do
    switch (setting) {
      case "silentMode":
        if (checkedValue) {
          alert("Silent Mode ON: App notifications will be muted. Emergency alerts will still sound.")
        } else {
          alert("Silent Mode OFF: All app notifications will play sounds.")
        }
        break
      case "locationSharing":
        if (checkedValue) {
          alert("Location Sharing ON: Your location will be shared with emergency contacts during incidents.")
        } else {
          alert("Location Sharing OFF: Location will not be shared automatically.")
        }
        break
      case "autoRecord":
        if (checkedValue) {
          alert("Auto-Record ON: Camera and microphone will start recording automatically during emergencies.")
        } else {
          alert("Auto-Record OFF: You'll need to manually start recording during emergencies.")
        }
        break
      case "nightMode":
        if (checkedValue) {
          alert("Night Mode ON: Screen brightness reduced, red-tinted interface for better night vision.")
        } else {
          alert("Night Mode OFF: Normal screen brightness and colors.")
        }
        break
    }

    console.log(`${setting} is now ${checkedValue ? "enabled" : "disabled"}`)
  }

  return (
    <div className="space-y-6">
      {/* Welcome Section with Status */}
      <Card className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <CardContent className="p-6">
          <div className="flex justify-between items-start">
            <div className="flex items-center space-x-3">
              <Shield size={32} />
              <div>
                <h1 className="text-2xl font-bold">Emergency Friend</h1>
                <p className="text-blue-100">Your personal safety companion</p>
              </div>
            </div>
            <div className="text-right">
              <div className="flex items-center space-x-2 mb-1">
                <Battery size={16} />
                <span className="text-sm">{batteryLevel}%</span>
              </div>
              <div className="flex items-center space-x-2">
                {isConnected ? <Wifi size={16} /> : <WifiOff size={16} />}
                <span className="text-sm">{isConnected ? "Online" : "Offline"}</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* System Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Activity size={20} />
            <span>System Status</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center">
              <div className="flex items-center justify-center space-x-2 mb-2">
                <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                <span className="font-semibold">All Systems Active</span>
              </div>
              <p className="text-sm text-gray-600">Emergency features ready</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-blue-600">{contactCount}</p>
              <p className="text-sm text-gray-600">Emergency Contacts</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Weather & Location Alerts */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <CloudRain size={20} />
            <span>Location & Weather</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {locationError && (
            <div className="mb-4 p-3 bg-red-50 rounded-lg border border-red-200 text-red-800 text-sm">
              <AlertTriangle size={16} className="inline mr-2" />
              {locationError}
            </div>
          )}
          {currentLocation ? (
            <div className="flex justify-between items-center mb-4">
              <div>
                <p className="font-semibold">
                  {currentWeather ? `${currentWeather.temp}°F - ${currentWeather.condition}` : "Fetching weather..."}
                </p>
                <p className="text-sm text-gray-600">{currentLocation.address}</p>
              </div>
              {currentWeather?.icon && (
                <img
                  src={`https://openweathermap.org/img/wn/${currentWeather.icon}@2x.png`}
                  alt={currentWeather.condition}
                  className="w-12 h-12"
                />
              )}
              {currentWeather?.alert && (
                <Badge className="bg-orange-600">
                  <AlertTriangle size={12} className="mr-1" />
                  Weather Alert
                </Badge>
              )}
            </div>
          ) : (
            <div className="text-center text-gray-600 py-4">
              <MapPin size={24} className="mx-auto mb-2" />
              <p>Waiting for location...</p>
            </div>
          )}

          {/* Updated Crime Alerts Section with Disclaimer */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <h4 className="font-semibold text-sm">Recent Crime Alerts</h4>
              <div className="flex items-center space-x-1">
                <Info size={12} className="text-blue-600" />
                <span className="text-xs text-blue-600">Sample Data</span>
              </div>
            </div>
            <div className="mb-2 p-2 bg-blue-50 rounded text-xs text-blue-700">
              <strong>Note:</strong> Crime alerts are currently sample data. In a real app, this would connect to local
              crime databases or police APIs.
            </div>
            {crimeAlerts.map((alert, index) => (
              <div key={index} className="flex justify-between items-center p-2 bg-red-50 rounded-lg">
                <div>
                  <p className="text-sm font-medium text-red-800">{alert.type}</p>
                  <p className="text-xs text-red-600">
                    {alert.location} • {alert.time}
                  </p>
                </div>
                <Badge className={alert.severity === "high" ? "bg-red-600" : "bg-orange-600"}>{alert.severity}</Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Enhanced Quick Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Zap size={20} />
            <span>Quick Settings</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="mb-2 p-2 bg-yellow-50 rounded text-xs text-yellow-700">
            <strong>Note:</strong> These settings simulate functionality. In a real app, they would control actual
            device features.
          </div>

          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-2">
              {quickSettings.silentMode ? <VolumeX size={16} /> : <Volume2 size={16} />}
              <div>
                <span>Silent Mode</span>
                <p className="text-xs text-gray-500">Mute app notifications</p>
              </div>
            </div>
            <Switch
              checked={quickSettings.silentMode}
              onCheckedChange={(checkedValue) => handleQuickSettingChange("silentMode", checkedValue)}
            />
          </div>

          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <MapPin size={16} />
              <div>
                <span>Location Sharing</span>
                <p className="text-xs text-gray-500">Share GPS with contacts</p>
              </div>
            </div>
            <Switch
              checked={quickSettings.locationSharing}
              onCheckedChange={(checkedValue) => handleQuickSettingChange("locationSharing", checkedValue)}
            />
          </div>

          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <Camera size={16} />
              <div>
                <span>Auto-Record</span>
                <p className="text-xs text-gray-500">Start recording in emergencies</p>
              </div>
            </div>
            <Switch
              checked={quickSettings.autoRecord}
              onCheckedChange={(checkedValue) => handleQuickSettingChange("autoRecord", checkedValue)}
            />
          </div>

          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-2">
              {quickSettings.nightMode ? <Moon size={16} /> : <Sun size={16} />}
              <div>
                <span>Night Mode</span>
                <p className="text-xs text-gray-500">Reduce brightness for night use</p>
              </div>
            </div>
            <Switch
              checked={quickSettings.nightMode}
              onCheckedChange={(checkedValue) => handleQuickSettingChange("nightMode", checkedValue)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Device Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Smartphone size={20} />
            <span>Connected Devices</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {deviceStatus.map((device, index) => (
            <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <device.icon size={20} className={device.color} />
                <div>
                  <p className="font-medium">{device.name}</p>
                  <p className="text-sm text-gray-600">{device.status}</p>
                </div>
              </div>
              {device.battery > 0 && (
                <div className="text-right">
                  <p className="text-sm font-medium">{device.battery}%</p>
                  <Progress value={device.battery} className="w-16 h-2" />
                </div>
              )}
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Safety Scenarios */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Navigation size={20} />
            <span>Quick Scenarios</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-3">
            {safetyScenarios.map((scenario, index) => (
              <Button
                key={index}
                variant="outline"
                className="h-auto p-3 flex flex-col items-center space-y-2 bg-transparent"
                onClick={() => {
                  const timerSettings = {
                    "First Date": { duration: 120, message: "Check on me - I'm on a first date at this location" },
                    Rideshare: { duration: 30, message: "Check on me - I'm in a rideshare to my destination" },
                    "Walking Home": { duration: 20, message: "Check on me - I'm walking home alone" },
                    "Business Trip": { duration: 240, message: "Check on me - I'm traveling for business" },
                    "Late Night Out": { duration: 60, message: "Check on me - I'm out late with friends" },
                    Jogging: { duration: 45, message: "Check on me - I'm out jogging in my neighborhood" },
                  }

                  const settings = timerSettings[scenario.name as keyof typeof timerSettings]
                  if (settings) {
                    onNavigate("timer", settings)
                  }
                }}
              >
                <scenario.icon size={24} className={`text-white p-1 rounded ${scenario.color}`} />
                <div className="text-center">
                  <p className="font-medium text-sm">{scenario.name}</p>
                  <p className="text-xs text-gray-600">{scenario.description}</p>
                </div>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Button
            onClick={() => onNavigate("timer")}
            className="w-full justify-start bg-orange-600 hover:bg-orange-700"
          >
            <Clock size={16} className="mr-2" />
            Set Check-In Timer
          </Button>

          <Button onClick={() => onNavigate("contacts")} variant="outline" className="w-full justify-start">
            <Users size={16} className="mr-2" />
            Manage Emergency Contacts
          </Button>

          <Button onClick={() => onNavigate("evidence")} variant="outline" className="w-full justify-start">
            <FileText size={16} className="mr-2" />
            Evidence Vault
          </Button>

          <Button
            variant="outline"
            className="w-full justify-start bg-transparent"
            onClick={() => {
              alert("Practice Mode: This would normally call 911. Call cancelled for safety.")
              console.log("Practice emergency call initiated")
            }}
          >
            <Phone size={16} className="mr-2" />
            Practice Emergency Call
          </Button>

          <Button
            variant="outline"
            className="w-full justify-start bg-transparent"
            onClick={() => {
              alert(
                "Alert Test: Emergency contacts would receive: 'This is a test alert from Emergency Friend. Please ignore.'",
              )
              console.log("Alert system test initiated")
            }}
          >
            <Bell size={16} className="mr-2" />
            Test Alert System
          </Button>
        </CardContent>
      </Card>

      {/* Safety Tips */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <TrendingUp size={20} />
            <span>Safety Tips</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {safetyTips.slice(0, 3).map((tip, index) => (
              <div key={index} className="flex items-start space-x-2 p-2 bg-blue-50 rounded-lg">
                <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></div>
                <p className="text-sm text-blue-800">{tip}</p>
              </div>
            ))}
          </div>
          <Button variant="outline" className="w-full mt-3 bg-transparent" size="sm">
            View All Tips
          </Button>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {recentActivity.map((activity, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-3 border-l-4 border-gray-200 pl-4 bg-gray-50 rounded-r-lg"
              >
                <div>
                  <p className="text-sm font-medium">{activity.action}</p>
                  <div className="flex items-center space-x-2 text-xs text-gray-500">
                    <span>{activity.time}</span>
                    <span>•</span>
                    <span>{activity.location}</span>
                  </div>
                </div>
                <Badge
                  variant={activity.status === "safe" ? "default" : "secondary"}
                  className={
                    activity.status === "safe"
                      ? "bg-green-600"
                      : activity.status === "success"
                        ? "bg-blue-600"
                        : "bg-gray-600"
                  }
                >
                  {activity.status}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Settings Quick Access */}
      <Button onClick={() => onNavigate("settings")} variant="outline" className="w-full">
        <Settings size={16} className="mr-2" />
        Settings & Privacy
      </Button>
    </div>
  )
}
