"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

interface DisguiseModeProps {
  onExitDisguise: () => void
  onEmergencyActivate: () => void
}

export function DisguiseMode({ onExitDisguise, onEmergencyActivate }: DisguiseModeProps) {
  const [display, setDisplay] = useState("0")
  const [secretCode, setSecretCode] = useState("")

  const handleButtonClick = (value: string) => {
    if (value === "C") {
      setDisplay("0")
      setSecretCode("")
    } else if (value === "=") {
      try {
        const result = eval(display)
        setDisplay(result.toString())
      } catch {
        setDisplay("Error")
      }
    } else {
      setDisplay(display === "0" ? value : display + value)
    }

    // Secret code to exit disguise: 911911
    const newSecretCode = secretCode + value
    if (newSecretCode === "911911") {
      onExitDisguise()
    } else if (newSecretCode === "999") {
      onEmergencyActivate()
    } else if (newSecretCode.length > 6) {
      setSecretCode("")
    } else {
      setSecretCode(newSecretCode)
    }
  }

  const buttons = [
    ["C", "±", "%", "÷"],
    ["7", "8", "9", "×"],
    ["4", "5", "6", "-"],
    ["1", "2", "3", "+"],
    ["0", ".", "="],
  ]

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-sm">
        <CardContent className="p-6">
          <div className="mb-4">
            <div className="bg-black text-white p-4 rounded text-right text-2xl font-mono min-h-[60px] flex items-center justify-end">
              {display}
            </div>
          </div>

          <div className="grid gap-2">
            {buttons.map((row, rowIndex) => (
              <div key={rowIndex} className="grid grid-cols-4 gap-2">
                {row.map((button) => (
                  <Button
                    key={button}
                    onClick={() => handleButtonClick(button)}
                    variant={["C", "±", "%", "÷", "×", "-", "+", "="].includes(button) ? "default" : "outline"}
                    className={`h-12 text-lg font-semibold ${button === "0" ? "col-span-2" : ""} ${
                      button === "=" ? "bg-orange-500 hover:bg-orange-600 text-white" : ""
                    }`}
                  >
                    {button}
                  </Button>
                ))}
              </div>
            ))}
          </div>

          <div className="mt-4 text-xs text-gray-500 text-center">Calculator v1.0</div>

          {/* Hidden emergency hints */}
          <div className="mt-2 text-xs text-gray-400 text-center">
            {secretCode.length > 0 && (
              <div>
                {secretCode.length >= 3 && secretCode.startsWith("999") && "Emergency code detected..."}
                {secretCode.length >= 6 && secretCode.startsWith("911911") && "Exiting disguise..."}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
