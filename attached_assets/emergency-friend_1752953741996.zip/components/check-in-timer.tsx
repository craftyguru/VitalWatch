"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Clock, Play, Square, AlertTriangle, XCircle } from "lucide-react" // Added XCircle icon
import type { CheckInTimer } from "../types"

interface CheckInTimerProps {
  timer: CheckInTimer | null
  onStartTimer: (timer: Omit<CheckInTimer, "id" | "isActive">) => void
  onStopTimer: () => void
  onCancelTimer: () => void
  scenarioSettings?: { duration: number; message: string } | null
  onClearScenario?: () => void
}

export function CheckInTimerComponent({
  timer,
  onStartTimer,
  onStopTimer,
  onCancelTimer,
  scenarioSettings,
  onClearScenario,
}: CheckInTimerProps) {
  const [duration, setDuration] = useState(scenarioSettings?.duration || 30)
  const [message, setMessage] = useState(scenarioSettings?.message || "")
  const [timeLeft, setTimeLeft] = useState(0)

  // Update state when scenarioSettings change
  useEffect(() => {
    if (scenarioSettings) {
      setDuration(scenarioSettings.duration)
      setMessage(scenarioSettings.message)
      // Do not clear scenario here, let the user explicitly clear it or start the timer
    } else {
      // Reset to default if no scenario is active
      setDuration(30)
      setMessage("")
    }
  }, [scenarioSettings])

  useEffect(() => {
    let interval: NodeJS.Timeout
    if (timer?.isActive && timer.startTime) {
      interval = setInterval(() => {
        const elapsed = Date.now() - timer.startTime!.getTime()
        const remaining = Math.max(0, timer.duration * 60 * 1000 - elapsed)
        setTimeLeft(remaining)

        if (remaining === 0) {
          onStopTimer()
        }
      }, 1000)
    } else if (timer === null && scenarioSettings) {
      // If no timer is active but a scenario is set, initialize timeLeft for display
      setTimeLeft(scenarioSettings.duration * 60 * 1000)
    } else {
      setTimeLeft(0) // Reset if no timer and no scenario
    }

    return () => clearInterval(interval)
  }, [timer, onStopTimer, scenarioSettings]) // Added scenarioSettings to dependencies

  const formatTime = (ms: number) => {
    const minutes = Math.floor(ms / 60000)
    const seconds = Math.floor((ms % 60000) / 1000)
    return `${minutes}:${seconds.toString().padStart(2, "0")}`
  }

  const handleStart = () => {
    onStartTimer({
      duration,
      message: message || `Check on me in ${duration} minutes`,
      contacts: [], // Would be populated with selected contacts
      startTime: new Date(),
    })
  }

  const handleClearScenarioClick = () => {
    if (onClearScenario) {
      onClearScenario()
    }
    setDuration(30) // Reset to default
    setMessage("") // Reset to default
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Safety Check-In Timer</h2>

      {!timer?.isActive ? (
        <Card>
          <CardHeader>
            <CardTitle>Set Check-In Timer</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {scenarioSettings && (
              <div className="mb-4 p-3 bg-blue-50 rounded-lg border border-blue-200 relative">
                <h4 className="font-semibold text-blue-800 mb-2">
                  Quick Scenario: {scenarioSettings.message.split(" - ")[0]}
                </h4>
                <p className="text-sm text-blue-700 mb-3">
                  This timer is pre-set for: <span className="font-medium">{scenarioSettings.message}</span>
                </p>
                <p className="text-sm text-blue-700 mb-3">
                  Duration: <span className="font-medium">{scenarioSettings.duration} minutes</span>
                </p>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleClearScenarioClick}
                  className="absolute top-2 right-2 text-blue-600 hover:text-blue-800 p-1 h-auto"
                  aria-label="Clear scenario"
                >
                  <XCircle size={16} />
                </Button>
                <Button onClick={handleStart} className="w-full bg-blue-600 hover:bg-blue-700">
                  Start {scenarioSettings.duration} Minute Timer
                </Button>
              </div>
            )}
            <div>
              <Label htmlFor="duration">Duration (minutes)</Label>
              <Select value={duration.toString()} onValueChange={(value) => setDuration(Number.parseInt(value))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="5">5 minutes</SelectItem>
                  <SelectItem value="10">10 minutes</SelectItem>
                  <SelectItem value="15">15 minutes</SelectItem>
                  <SelectItem value="30">30 minutes</SelectItem>
                  <SelectItem value="60">1 hour</SelectItem>
                  <SelectItem value="120">2 hours</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="message">Custom Message (Optional)</Label>
              <Input
                id="message"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder={`Check on me in ${duration} minutes`}
              />
            </div>

            {!scenarioSettings && ( // Only show this button if no scenario is active
              <Button onClick={handleStart} className="w-full flex items-center space-x-2">
                <Play size={16} />
                <span>Start Timer</span>
              </Button>
            )}
          </CardContent>
        </Card>
      ) : (
        <Card className="border-orange-200 bg-orange-50">
          <CardContent className="p-6">
            <div className="text-center space-y-4">
              <div className="flex justify-center">
                <Clock size={48} className="text-orange-600" />
              </div>

              <div>
                <h3 className="text-2xl font-bold text-orange-800">{formatTime(timeLeft)}</h3>
                <p className="text-orange-600">Time remaining</p>
              </div>

              <div className="bg-white p-3 rounded-lg">
                <p className="text-sm text-gray-700">{timer.message}</p>
              </div>

              <div className="flex space-x-2">
                <Button onClick={onCancelTimer} className="flex-1 bg-green-600 hover:bg-green-700">
                  <span>I'm Safe - Cancel Timer</span>
                </Button>
                <Button onClick={onStopTimer} variant="outline" className="flex-1 bg-transparent">
                  <Square size={16} />
                  <span>Stop</span>
                </Button>
              </div>

              {timeLeft < 60000 && (
                <div className="flex items-center justify-center space-x-2 text-red-600 animate-pulse">
                  <AlertTriangle size={16} />
                  <span className="text-sm font-semibold">Alert will be sent soon!</span>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>How It Works</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2 text-sm text-gray-600">
            <li>• Set a timer for risky situations (dates, travel, etc.)</li>
            <li>• If you don't check in before time expires, alerts are sent</li>
            <li>• Your emergency contacts receive your location and status</li>
            <li>• Cancel anytime by pressing "I'm Safe"</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}
