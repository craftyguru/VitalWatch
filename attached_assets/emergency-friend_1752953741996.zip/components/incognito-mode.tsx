"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Shield, Eye, MapPin, Clock } from "lucide-react"

interface IncognitoModeProps {
  onExitIncognito: () => void
  onEmergencyActivate: () => void
}

export function IncognitoMode({ onExitIncognito, onEmergencyActivate }: IncognitoModeProps) {
  const [isExpanded, setIsExpanded] = useState(false)

  return (
    <div className="fixed top-4 right-4 z-50">
      {!isExpanded ? (
        // Floating Emergency Button
        <Button
          onClick={() => setIsExpanded(true)}
          className="w-16 h-16 rounded-full bg-red-600 hover:bg-red-700 shadow-lg animate-pulse"
          onDoubleClick={onEmergencyActivate}
        >
          <Shield size={24} className="text-white" />
        </Button>
      ) : (
        // Expanded Quick Access Panel
        <Card className="w-64 shadow-xl">
          <CardContent className="p-4 space-y-3">
            <div className="flex justify-between items-center">
              <h3 className="font-semibold text-sm">Emergency Friend</h3>
              <Button size="sm" variant="ghost" onClick={() => setIsExpanded(false)} className="h-6 w-6 p-0">
                ×
              </Button>
            </div>

            <div className="space-y-2">
              <Button onClick={onEmergencyActivate} className="w-full bg-red-600 hover:bg-red-700 text-sm" size="sm">
                <Shield size={14} className="mr-2" />
                Emergency
              </Button>

              <div className="grid grid-cols-2 gap-2">
                <Button variant="outline" size="sm" className="text-xs bg-transparent">
                  <MapPin size={12} className="mr-1" />
                  Share Location
                </Button>
                <Button variant="outline" size="sm" className="text-xs bg-transparent">
                  <Clock size={12} className="mr-1" />
                  Quick Timer
                </Button>
              </div>

              <Button onClick={onExitIncognito} variant="outline" size="sm" className="w-full text-xs bg-transparent">
                <Eye size={12} className="mr-2" />
                Show Full App
              </Button>
            </div>

            <div className="text-xs text-gray-500 text-center">Double-tap red button for instant emergency</div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
