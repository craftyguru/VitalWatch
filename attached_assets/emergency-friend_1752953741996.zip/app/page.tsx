import EmergencyFriendApp from "../emergency-friend-app"

export default function Page() {
  return <EmergencyFriendApp />
}
