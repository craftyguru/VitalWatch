import { NextResponse } from "next/server"
import OpenAI from "openai" // Import the OpenAI client
import { generateText } from "ai" // Import generateText from AI SDK
import { openai } from "@ai-sdk/openai" // Import OpenAI model from AI SDK

// Initialize OpenAI client with your API key
// Ensure NEXT_PUBLIC_OPENAI_API_KEY is set in your environment variables
const openaiClient = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY, // This should be your secret API key
})

export async function POST(request: Request) {
  try {
    // 1. Receive the audio blob from the frontend
    const audioBlob = await request.blob()
    console.log(`Received audio chunk of size: ${audioBlob.size} bytes`)

    // 2. Convert Blob to a File object for OpenAI API
    // OpenAI's Whisper API expects a 'File' object or a Node.js 'Readable' stream.
    // We create a File-like object from the Blob.
    const audioFile = new File([audioBlob], "audio.webm", { type: "audio/webm" })

    // 3. Send audio to OpenAI Whisper for Speech-to-Text transcription
    const transcription = await openaiClient.audio.transcriptions.create({
      file: audioFile,
      model: "whisper-1", // Use the Whisper model for transcription
    })

    const userSpeech = transcription.text
    console.log("Transcribed User Speech:", userSpeech)

    // If no speech detected, return a placeholder or skip AI analysis
    if (!userSpeech || userSpeech.trim() === "") {
      return NextResponse.json({
        success: true,
        transcript: `${new Date().toLocaleTimeString()}: (No clear speech detected)`,
      })
    }

    // 4. Use AI SDK to generate an AI response based on the transcribed user speech
    const { text: aiResponse } = await generateText({
      model: openai("gpt-4o"), // Use a powerful model for better analysis
      system:
        "You are an AI safety assistant for an emergency app. Your role is to monitor conversations, detect distress, provide calm and helpful responses, and summarize critical information. Do not act as a chatbot for general conversation. Focus on safety and emergency-related cues. Keep responses concise and actionable. If the user seems safe or is just testing, acknowledge that.",
      prompt: `User said: "${userSpeech}". Provide a concise AI witness observation or response.`,
    })

    const timestamp = new Date().toLocaleTimeString()

    return NextResponse.json({
      success: true,
      transcript: `${timestamp}: ${aiResponse}`,
    })
  } catch (error) {
    console.error("Error in AI Witness API route:", error)
    // Provide more specific error messages for debugging
    let errorMessage = "Failed to process audio."
    if (error instanceof OpenAI.APIError) {
      errorMessage = `OpenAI API Error: ${error.status} - ${error.message}`
    } else if (error instanceof Error) {
      errorMessage = `Server Error: ${error.message}`
    }

    return NextResponse.json(
      {
        success: false,
        error: errorMessage,
      },
      { status: 500 },
    )
  }
}
