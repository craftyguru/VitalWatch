export interface Contact {
  id: string
  name: string
  phone: string
  email?: string
  role: "primary" | "backup" | "professional"
  avatar?: string
}

export interface LocationData {
  lat: number
  lng: number
  address: string // Human-readable address
  timestamp?: number // When this location was recorded
}

export interface EmergencySession {
  id: string
  startTime: Date
  endTime?: Date
  location: LocationData // Use the new LocationData type
  recordings: string[]
  transcript: string[]
  status: "active" | "resolved" | "cancelled"
  alertsSent: string[]
}

export interface CheckInTimer {
  id: string
  duration: number
  message: string
  contacts: string[]
  isActive: boolean
  startTime?: Date
}

export type AppMode = "dashboard" | "emergency" | "contacts" | "settings" | "evidence"

export interface WeatherData {
  temp: number
  condition: string
  icon: string // e.g., "01d" for clear sky day
  alert: boolean
  city: string
  country: string
}
